<?php

namespace app\modules\admin\controllers;


/**
 * ApiParamOutputController implements the CRUD actions for ApiParam model.
 */
class ApiParamOutputController extends ApiParamController
{

}
